extends CharacterBody2D


var maxSpeed = 100
var lastDirection := Vector2(1,0)
var direction 

func _physics_process(delta: float) -> void:
	#directional movmenet
	var direction = Input.get_vector("moveLeft", "moveRight", "moveUp", "moveDown")
# stop diagonal movement by listening for input then setting axis to zero
	if Input.is_action_pressed("moveRight") || Input.is_action_pressed("moveLeft"):
		direction.y = 0
	elif Input.is_action_pressed("moveUp") || Input.is_action_pressed("moveDown"):
		direction.x = 0
	else:
		direction = Vector2.ZERO
	
#normalize the directional movement
	direction = direction.normalized()
# setup the actual movement
	velocity = (direction * maxSpeed)
	move_and_slide()
	
	
	if direction.length() >0:
		lastDirection = direction
		play_move_animation(direction)
	else:
		play_Idle_Animation(lastDirection)
	

func play_move_animation(direction):
	if direction.x >0:
		$AnimatedSprite2D.play("moveRight")
	elif direction.x <0:
		$AnimatedSprite2D.play("moveLeft")
	elif direction.y >0:
		$AnimatedSprite2D.play("moveDown")
	elif direction.y <0:
		$AnimatedSprite2D.play("moveUp")


func play_Idle_Animation(direction):
	if direction.x > 0:
		$AnimatedSprite2D.play("idleRight")
	elif direction.x < 0:
		$AnimatedSprite2D.play("idleLeft")
	elif direction.y > 0:
		$AnimatedSprite2D.play("idleDown")
	elif direction.y < 0:
		$AnimatedSprite2D.play("idleUp")
		
		
		
