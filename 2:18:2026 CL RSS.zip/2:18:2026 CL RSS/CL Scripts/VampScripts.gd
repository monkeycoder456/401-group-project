extends CharacterBody2D

@export var tilemap: TileMapLayer
@export var move_speed: float = 90.0
@export var move_delay: float = 0.0

var current_cell: Vector2i
var target_position: Vector2
var moving := false

const DIRS: Dictionary[Vector2i, String] = {
	Vector2i.UP: "N",
	Vector2i.DOWN: "S",
	Vector2i.LEFT: "W",
	Vector2i.RIGHT: "E"
}

func _ready():
	current_cell = tilemap.local_to_map(global_position)
	target_position = global_position
	randomize()
	_start_wander()

func _physics_process(delta):
	if moving:
		global_position = global_position.move_toward(target_position, move_speed * delta)
		if global_position.distance_to(target_position) < 1:
			global_position = target_position
			moving = false
			await get_tree().create_timer(move_delay).timeout
			_start_wander()

func _start_wander():
	var possible_dirs := _get_available_dirs()
	if possible_dirs.is_empty():
		return

	var dir: Vector2i = possible_dirs.pick_random()
	current_cell += dir
	target_position = tilemap.map_to_local(current_cell)
	moving = true
	_play_animation(dir)

func _get_available_dirs() -> Array[Vector2i]:
	var results: Array[Vector2i] = []
	var tile_data := tilemap.get_cell_tile_data(current_cell)

	if tile_data == null:
		return results

	for dir in DIRS.keys():
		var key := DIRS[dir]
		if tile_data.get_custom_data(key):
			results.append(dir)

	return results

func _play_animation(dir: Vector2i):
	var anim := $AnimatedSprite2D
	if dir == Vector2i.UP:
		anim.play("up")
	elif dir == Vector2i.DOWN:
		anim.play("down")
	elif dir == Vector2i.LEFT:
		anim.play("left")
	elif dir == Vector2i.RIGHT:
		anim.play("right")
