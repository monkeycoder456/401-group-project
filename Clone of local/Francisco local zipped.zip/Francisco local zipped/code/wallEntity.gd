class_name Wall_enity extends GenericMazeEntity

#this class to test the idea of having a maze entity
#that can block other maze entities

#the maze entity should hav an area 2d to dectect stuff around it,
#more specifically things attempting to enter it's cell. when a thing
#tries to enter it's cell, it will get that node via area2d, and "cancle"
#the movement. all maze entities share the same underlying class members, so 
#get the direction they are attempting to go into
