extends CharacterBody2D

@export var tilemap: TileMapLayer
@export var player: CharacterBody2D
@export var move_speed: float = 200.0
@export var dizzy_time: float = 4.0

var current_cell: Vector2i
var target_position: Vector2
var direction: Vector2i = Vector2i.ZERO
var dizzy := false

const DIRS = {
	Vector2i.UP: "N",
	Vector2i.DOWN: "S",
	Vector2i.LEFT: "W",
	Vector2i.RIGHT: "E"
}


func _ready():

	randomize()
# spawn for seed 10 (30,5)
	current_cell = Vector2i(30,5)

	target_position = tilemap.map_to_local(current_cell)
	global_position = target_position

	choose_random_direction()



func _physics_process(delta):

	if dizzy:
		return

	global_position = global_position.move_toward(
		target_position,
		move_speed * delta
	)

	check_player_collision()

	if global_position.distance_to(target_position) < 1:

		global_position = target_position

		if can_move(direction):
			current_cell += direction
			target_position = tilemap.map_to_local(current_cell)
		else:
			become_dizzy()



func choose_random_direction():

	var dirs = get_available_dirs()

	if dirs.is_empty():
		return

	direction = dirs.pick_random()

	play_move_animation(direction)

	current_cell += direction
	target_position = tilemap.map_to_local(current_cell)



func become_dizzy():

	dizzy = true

	play_dizzy_animation(direction)

	await get_tree().create_timer(dizzy_time).timeout

	dizzy = false

	choose_random_direction()



func can_move(dir):

	# Prevent dictionary error if direction is (0,0)
	if not DIRS.has(dir):
		return false

	var tile_data = tilemap.get_cell_tile_data(current_cell)

	if tile_data == null:
		return false

	return tile_data.get_custom_data(DIRS[dir]) == true



func get_available_dirs():

	var results = []

	var tile_data = tilemap.get_cell_tile_data(current_cell)

	if tile_data == null:
		return results

	for dir in DIRS.keys():

		var key = DIRS[dir]

		if tile_data.get_custom_data(key) == true:
			results.append(dir)

	return results



func check_player_collision():

	if player == null:
		return

	if global_position.distance_to(player.global_position) < 16:
		player.player_die()



func play_move_animation(dir):

	var anim = $AnimatedSprite2D

	if dir == Vector2i.UP:
		anim.play("up")
	elif dir == Vector2i.DOWN:
		anim.play("down")
	elif dir == Vector2i.LEFT:
		anim.play("left")
	elif dir == Vector2i.RIGHT:
		anim.play("right")



func play_dizzy_animation(dir):

	var anim = $AnimatedSprite2D

	if dir == Vector2i.UP:
		anim.play("dizzyup")
	elif dir == Vector2i.DOWN:
		anim.play("dizzydown")
	elif dir == Vector2i.LEFT:
		anim.play("dizzyleft")
	elif dir == Vector2i.RIGHT:
		anim.play("dizzyright")
