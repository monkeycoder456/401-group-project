extends CharacterBody2D

@export var tilemap: TileMapLayer
@export var player: CharacterBody2D
@export var move_speed: float = 80.0

var current_cell: Vector2i
var target_position: Vector2
var last_dir: Vector2i = Vector2i.ZERO

const DIRS: Dictionary[Vector2i, String] = {
	Vector2i.UP: "N",
	Vector2i.DOWN: "S",
	Vector2i.LEFT: "W",
	Vector2i.RIGHT: "E"
}


func _ready():
#Spawn for seed 10 (39,3)
	current_cell = Vector2i(39,3)

	target_position = tilemap.map_to_local(current_cell)
	global_position = target_position

	_choose_direction()



func _physics_process(delta):

	global_position = global_position.move_toward(
		target_position,
		move_speed * delta
	)

	_check_player_collision()

	if global_position.distance_to(target_position) < 1:
		global_position = target_position
		_choose_direction()



func _choose_direction():

	var possible_dirs := _get_available_dirs()

	if possible_dirs.is_empty():
		return

	if last_dir != Vector2i.ZERO and possible_dirs.size() > 1:
		possible_dirs.erase(-last_dir)


	var player_cell = tilemap.local_to_map(
		tilemap.to_local(player.global_position)
	)

	var best_dir := possible_dirs[0]
	var best_distance := INF


	for dir in possible_dirs:

		var next_cell = current_cell + dir
		var dist = next_cell.distance_to(player_cell)

		if dist < best_distance:
			best_distance = dist
			best_dir = dir


	last_dir = best_dir
	current_cell += best_dir

	target_position = tilemap.map_to_local(current_cell)

	_play_animation(best_dir)



func _get_available_dirs() -> Array[Vector2i]:

	var results: Array[Vector2i] = []

	var tile_data := tilemap.get_cell_tile_data(current_cell)

	if tile_data == null:
		return results

	for dir in DIRS.keys():

		if tile_data.get_custom_data(DIRS[dir]):
			results.append(dir)

	return results



func _check_player_collision():

	if player == null:
		return

	if global_position.distance_to(player.global_position) < 16:
		player.player_die()



func _play_animation(dir: Vector2i):

	var anim := $AnimatedSprite2D

	if dir == Vector2i.UP:
		anim.play("up")
	elif dir == Vector2i.DOWN:
		anim.play("down")
	elif dir == Vector2i.LEFT:
		anim.play("left")
	elif dir == Vector2i.RIGHT:
		anim.play("right")
