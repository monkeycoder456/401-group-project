class_name Player extends CharacterBody2D

@export var tilemap: TileMapLayer

var maxSpeed := 100
var lastDirection := Vector2.RIGHT
var dead := false

var current_cell: Vector2i

const DIRS = {
	Vector2i.UP: "N",
	Vector2i.DOWN: "S",
	Vector2i.LEFT: "W",
	Vector2i.RIGHT: "E"
}


func _ready():

	if tilemap != null:
#Spawn for seed 10 (0,4)
		current_cell = Vector2i(0,4)
		global_position = tilemap.map_to_local(current_cell)



func _physics_process(_delta):
	#print("global pos: ", global_position)
	#print("maze pos: ", current_cell)
	if dead:
		return

	var input_dir = Input.get_vector("ui_left","ui_right","ui_up","ui_down")

	var direction := Vector2.ZERO

	# prevent diagonal movement
	if input_dir.x != 0:
		direction = Vector2(sign(input_dir.x),0)
	elif input_dir.y != 0:
		direction = Vector2(0,sign(input_dir.y))

	if direction != Vector2.ZERO:

		var grid_dir := Vector2i(direction)

		if can_move(grid_dir):

			lastDirection = direction

			velocity = direction * maxSpeed
			move_and_slide()

			current_cell = tilemap.local_to_map(global_position)

			play_move_animation(direction)

		else:

			velocity = Vector2.ZERO
			play_idle_animation(lastDirection)

	else:

		velocity = Vector2.ZERO
		play_idle_animation(lastDirection)



func can_move(dir: Vector2i) -> bool:

	if not DIRS.has(dir):
		return false

	var tile_data = tilemap.get_cell_tile_data(current_cell)

	if tile_data == null:
		return false

	return tile_data.get_custom_data(DIRS[dir]) == true



func play_move_animation(direction):

	if direction.x > 0:
		$AnimatedSprite2D.play("right")
	elif direction.x < 0:
		$AnimatedSprite2D.play("left")
	elif direction.y > 0:
		$AnimatedSprite2D.play("down")
	elif direction.y < 0:
		$AnimatedSprite2D.play("up")



func play_idle_animation(direction):

	if direction.x > 0:
		$AnimatedSprite2D.play("idleright")
	elif direction.x < 0:
		$AnimatedSprite2D.play("idleleft")
	elif direction.y > 0:
		$AnimatedSprite2D.play("idledown")
	elif direction.y < 0:
		$AnimatedSprite2D.play("idleup")



func player_die():

	if dead:
		return

	dead = true

	print("Player died")

	velocity = Vector2.ZERO

	$AnimatedSprite2D.stop()

	visible = false

	if $CollisionShape2D:
		$CollisionShape2D.disabled = true

	set_physics_process(false)
