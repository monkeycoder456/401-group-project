class_name tilemapproxy extends Object
#this whole file IS the class
var rows
var columns

func _init():
	
