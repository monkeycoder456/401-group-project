class_name blocklayer extends Node
#for aid in maze generation
var rows : int
var columns : int
var myMatrix : Array
#-1 equals blank tile
# literally any other number means filled tile.

func _init(crows, molumns):
	rows = crows
	columns = molumns
	for i in range(rows):
		myMatrix.append([])
		for j in range(columns):
			myMatrix[i].append(-1)

func printMe():
	for rog in myMatrix:
		print(rog)

func getpoint(vector:Vector2i):
	return myMatrix[vector.y][vector.x]

func check_if_spot_free(vector : Vector2i):
	if(getpoint(vector) == -1):
		return true
	else:
		return false

func check_if_area_free(topleft : Vector2i, bottomright : Vector2i):
	#checks if the asked area is free, INCLUSIVE ON BOTH ENDS
	#if true, free
	#if false, not free
	for i in range(bottomright.y - topleft.y + 1):
		#NOTE: ensure topleft is applied as offset
		print(i + topleft.y)
		for j in range(bottomright.x - topleft.x + 1):
			#NOTE: ensure topleft is applied as offset
			print(j + topleft.y)
			if(check_if_spot_free(Vector2i(j,i)) == false):
				return false
			else:
				pass
	return true

func fill_area_with_num(num : int, topleft : Vector2,bottomright : Vector2i):
	for i in range(bottomright.y - topleft.y + 1):
		#NOTE: ensure topleft is applied as offset
		print(i + topleft.y)
		for j in range(bottomright.x - topleft.x + 1):
			#NOTE: ensure topleft is applied as offset
			print(j + topleft.y)
			if(check_if_spot_free(Vector2i(j,i)) == false):
				return false
			else:
				pass
	pass
