extends Control

@export var the_scene_to_load := "res://scenes/demonstration.tscn"

func _on_playbutton_pressed() -> void:
	get_tree().change_scene_to_file(the_scene_to_load)


func _on_quitbutt_pressed() -> void:
	get_tree().quit()
