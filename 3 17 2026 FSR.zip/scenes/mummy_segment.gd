extends "res://code/GenericMazeEntity.gd"

func _ready():
	pass

func _physics_process(delta):
	pass
