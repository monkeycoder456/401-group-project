class_name Mazery extends TileMapLayer

var DIRECTIONS = {"N"=Vector2i(0,-1),"S"=Vector2i(0,1),"E"=Vector2i(1,0),"W"=Vector2i(-1,0)}
var DIRECTION_TO_NUM = {"N"=0,"S"=1,"E"=2,"W"=3}
var OPPOSITES = {"N"="S","S"="N","E"="W","W"="E"}
var POLARIZED = {"N"=["E","W"],"S"=["E","W"],"E"=["N","S"],"W"=["N","S"]}

var proxy : tilemapproxy
var blocks : blocklayer



#these are the shapes that are allowed to fill.
#if a shape doesn't work out then we must deviate...
#they are all rectangles and squares
#written as "name":[x,y]
#where x is the columns it occupies
#and y is the rows it occupies 
var SHAPES = {"Square2"=[2,2], "Rectangle32"=[3,2],"Rectangle23"=[2,3],"Square3"=[3,3],"Rectangle42"=[4,2],"Rectangle24"=[2,4],"Square4"=[4,4]}

# Called when the node enters the scene tree for the first time.
func _ready():
	#for i in ordinal.keys().size():
		#var dir = ordinal.get(ordinal.keys()[i])
		#set_cell(Vector2i(dir[0],dir[1]),1,Vector2i(3,3))
	_make_me_maze()
	pass # Replace with function body.

 #Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	pass

func binToInt(array : Array):
	if array[0] == false:
		if array[1] == false:
			return 0
		else:
			return 1
	else:
		if array[1] == false:
			return 2
		else:
			return 3

func getRandomShape():
	#returns a random shape from shapes dict
	return SHAPES.get(SHAPES.keys().pick_random())

func shapeToVectorPair(topLeft : Vector2i,shapeDimensions : Array):
	#returns two vectors
	var bottomRight = Vector2i(topLeft.x + shapeDimensions[0], topLeft.y + shapeDimensions[1])
	return [topLeft, bottomRight]

func _make_me_maze():
	#fill world with debug tile (le BLANK tile)
	seed(10)
	var rows = 20
	var columns = 20
	proxy = tilemapproxy.new(rows,columns)
	blocks = blocklayer.new(rows,columns)
	var origin_tile = Vector2i(rows/2,columns/2)
	for i in range(rows): #rows
		for j in range(columns): #columns
			if (i == origin_tile.x) and (j == origin_tile.y):
				#print("middle")
				set_cell(Vector2i(j,i),1,Vector2i(0,7))
			else:
				set_cell(Vector2i(j,i),1,Vector2i(4,1))
	#with the actual tile layer done, begin work on proxy
	#proxy.printMe()
	#blocks.printMe()
	#through blocks begin placing random blocks
	#you will need to loop the below until:
		#you can no longer place valid blocks
	#var shape_to_place = getRandomShape()
	#var shape_vectors = shapeToVectorPair(Vector2i(2,3),shape_to_place)
	#print(shape_vectors)
	#print(blocks.check_if_area_free(shape_vectors[0],shape_vectors[1]))
	#blocks.fill_area_with_num(0,shape_vectors[0],shape_vectors[1])
	#blocks.printMe()
	
	block_placing(origin_tile)
	print("exited block placing. here is the block map")
	#blocks.printMe()
	print("converting block map into tilemap proxy...")
	#proxy.printMe()
	block_to_tile_proxy()
	print("done with conversion")
	#proxy.printMe()
	print("pushing changes to tile map earily: WARNING THIS IS FOR DEBUGGING ONLY")
	proxy_to_tile_map_layer()
	print("connecting sections")
	proxy.connect_sections()
	print("pushing changes to tile map earily: WARNING THIS IS FOR DEBUGGING ONLY")
	proxy_to_tile_map_layer()
	print("removing redundent tiles\n these tiles are surrounded by valid path\n. these tiles will become invalid")
	remove_redundent()
	print("pushing changes to tile map earily: WARNING THIS IS FOR DEBUGGING ONLY")
	proxy_to_tile_map_layer()
	print("classifying tiles")
	tile_discriminator()

func find_valid_offset(edge : Vector2i,shapedefinition : Array):
	var offset = Vector2i(0,0)
	var able = true
	while(able):
		var worked = blocks.check_if_area_free(edge + shapedefinition[0] + offset, edge + shapedefinition[1] + offset)
		if(worked):
			return offset
		else:
			#offset didn't work.
			#increment by -1
			offset.x -= 1
			if (abs(offset.x) > shapedefinition[1].x):
				offset.x = 0
				offset.y -= 1
			if (abs(offset.y) > shapedefinition[1].y):
				#couldn't find it. give up and return fail
				#print("failed to find offset")
				return Vector2(NAN,NAN)
			#if abs(offset.x) > shapedefinition.x then set offset.x to 0; decrement offset.y by -1
			#if abs(offset.y) > shapedefintion.y then return vector2(-inf,-inf) AKA didnt work

func block_placing(originVect : Vector2i):
	#origin vector is where the "holy square will go"
	blocks.writepoint(originVect,0)
	var can_place = true
	var block_num = 1
	while(can_place):
		#print("should we be working?", can_place)
		#get a random shape
		#region shape selected. tryign to use it
		#instead shuffle the shapes array and do a for loop
		#when encountering an unusable shape, skip it
		#when we run out of shapes. shuffle and repeat
			var shapes_to_use = SHAPES.values()
			shapes_to_use.shuffle()
			for shape_to_place in shapes_to_use:
				var shape_vectors = shapeToVectorPair(Vector2i(0,0),shape_to_place)
				#print("shape vectors")
				#print(shape_vectors)
				#shape vector is how we will represent our shape
				
				#find the edges of what we have worked with
				#print("going to find edges")
				var edges = blocks.find_edges(originVect)
				#print("have left find edges")
				
				#pick a random edge cell
				var tile_to_use
				#region using edges until valid found
				edges.shuffle()
				#print(edges)
				for edge in edges:
					tile_to_use = edge
					var offset = find_valid_offset(tile_to_use,shape_vectors)
					#print("working offset: ", offset, " for edge ", tile_to_use)
					if (!is_nan(offset.x)):
						#print("we can place!!")
						can_place = true
						blocks.fill_area_with_num(block_num,offset + shape_vectors[0]+tile_to_use,offset + shape_vectors[1]+tile_to_use)
						#blocks.printMe()
						block_num += 1
						break
					else:
						can_place = false
				#endregion leaving hear means we found a workable edge
				#endregion being here means we finsished with placing a shape
			
	#region debug cancel early
		#print("can we still place? ", can_place)
	print("exited while loop")
	#endregion

func block_to_tile_proxy():
	for row in blocks.myMatrix.size(): #this is Y
		for cell in blocks.myMatrix[0].size(): #this is X
			#take the cell, look at all neighboors
			#for every neighboor that shares that cell's value. make a connection in that direction
			#thats it.
			for nieghboor in DIRECTIONS:
				if blocks.getpoint(Vector2i(cell,row)) == -1:
					continue
				if inbounds(Vector2i(cell,row) + DIRECTIONS.get(nieghboor)):
					print("self ",Vector2i(cell,row)," with value ", blocks.getpoint(Vector2i(cell,row)), " neighboor ", Vector2i(cell,row) + DIRECTIONS.get(nieghboor), " with value ",blocks.getpoint(Vector2i(cell,row) + DIRECTIONS.get(nieghboor)), " matching? ",blocks.getpoint(Vector2i(cell,row) + DIRECTIONS.get(nieghboor)) == blocks.getpoint(Vector2i(cell,row)))
					if blocks.getpoint(Vector2i(cell,row)) == blocks.getpoint(Vector2i(cell,row) + DIRECTIONS.get(nieghboor)):
						print("found valid neighboor :-)")
						proxy.carvePath(Vector2i(cell,row),nieghboor)
			#print("this tile's connections are ",proxy.getpoint(Vector2i(cell,row)))

func inbounds(vect_to_check :Vector2i):
	if (vect_to_check.x >= blocks.myMatrix[0].size() or vect_to_check.y >= blocks.myMatrix.size()) or (vect_to_check.x < 0 or vect_to_check.y < 0):
		return false
	else:
		return true

func proxy_to_tile_map_layer():
	#for each cell in proxy
	#use the binary trick i though of [N,S,E,W] => [00,00] => [int,int] => find appropriate tile in tileset
	#assign the correct tile values
	for row in proxy.myMatrix.size(): #this is Y
		for cell in proxy.myMatrix[0].size(): #this is X
			var data = proxy.getpoint(Vector2i(cell,row))
			var NS = binToInt([data[0],data[1]])
			var EW = binToInt([data[2],data[3]])
			print("data ",data," converted into int pair ", binToInt([data[0],data[1]]),binToInt([data[2],data[3]]))
			set_cell(Vector2i(cell,row),1,Vector2i(EW,NS))
	pass

func remove_redundent():
	var notNegOne = []
	for row in blocks.myMatrix.size(): #this is Y
		for cell in blocks.myMatrix[0].size(): #this is X
			print(row, " ", cell)
			if(blocks.getpoint(Vector2i(cell,row)) != -1):
				notNegOne.append(Vector2i(cell,row))
	var notBoarder = []
	var Boarder = []
	for cell in notNegOne:
		#if blocks.inbound(cell) == true:
			#notBoarder.append(cell)
		for dir in DIRECTIONS:
			print(dir)
			var neighbor = cell + DIRECTIONS.get(dir)
			if(not(inbounds(neighbor))):
				Boarder.append(cell)

	#region filter boarder from notNegOne
	for cell in notNegOne:
		if(not(Boarder.has(cell))):
			notBoarder.append(cell)
	#endregion

	var toRemove = []
	for cell in notBoarder:
		var edge = true
		for dir in DIRECTIONS:
			print(dir)
			var neighbor = cell + DIRECTIONS.get(dir)
			if not(blocks.getpoint(cell) == blocks.getpoint(neighbor)):
				edge = false
		if (edge == true):
			toRemove.append(cell)
	for cell in toRemove:
		for dir in DIRECTIONS:
			print(dir)
			var neighbor = cell + DIRECTIONS.get(dir)
			proxy.uncarve(cell,dir)
		set_cell(cell,1,Vector2i(0,7))

func tile_discriminator():
	var hallways = [] #represented with H
	var hallwayCorner = [] #rep with CH
	var tJunction = [] #rep with T
	var crossing = [] #rep with X
	var junk = [] #reperesented with question mark
	
	for row in proxy.myMatrix.size(): #this is Y
		for cell in proxy.myMatrix[0].size(): #this is X
			var data = proxy.getpoint(Vector2i(cell,row))
			#hallway check
			if(data[0] and data[1] and not(data[2]) and not(data[3])) or (not(data[0]) and not(data[1]) and data[2] and data[3]):
				hallways.append(Vector2i(cell,row))
				#set_cell(Vector2i(cell,row),1,Vector2i(5,0))
			#hallway corner check
			elif(data[0] and not(data[1]) and not(data[2]) and data[3]) or (data[0] and not(data[1]) and data[2] and not(data[3])) or (not(data[0]) and data[1] and not(data[2]) and data[3]) or (not(data[0]) and data[1] and data[2] and not(data[3])):
				hallwayCorner.append(Vector2i(cell,row))
				#set_cell(Vector2i(cell,row),1,Vector2i(6,0))
			elif((not(data[0]) and data[1] and data[2] and data[3]) or (data[0] and not(data[1]) and data[2] and data[3]) or (data[0] and data[1] and not(data[2]) and data[3]) or (data[0] and data[1] and data[2] and not(data[3]))):
				tJunction.append(Vector2i(cell,row))
				#set_cell(Vector2i(cell,row),1,Vector2i(7,0))
			elif(data[0] and data[1] and data[2] and data[3]):
				crossing.append(Vector2i(cell,row))
				#set_cell(Vector2i(cell,row),1,Vector2i(5,1))
			else:
				junk.append(Vector2i(cell,row))
				#set_cell(Vector2i(cell,row),1,Vector2i(6,1))
	pass
