class_name MazeryExtraData extends TileMapLayer


# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	pass

func assign(where :Vector2i, what: Vector2i):
	set_cell(where,0,what)
