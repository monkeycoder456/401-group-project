extends Control


func _on_playbutton_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/map1.tscn")


func _on_quitbutt_pressed() -> void:
	get_tree().quit()
