extends Control

var lives := 3
var time_left := 180.0

@onready var heart1 = $HeartsContainer/Heart1
@onready var heart2 = $HeartsContainer/Heart2
@onready var heart3 = $HeartsContainer/Heart3

@onready var timer_label = $TimerFrame/TimerLabel


func _ready():
	await get_tree().process_frame
	update_hearts()
	update_timer()


func _process(delta):
	if time_left > 0:
		time_left -= delta
		update_timer()


func update_timer():
	var total = int(time_left)
	var minutes = total / 60
	var seconds = total % 60
	timer_label.text = "%02d:%02d" % [minutes, seconds]


func take_damage():
	lives -= 1
	lives = clamp(lives, 0, 3)
	update_hearts()


func heal():
	lives += 1
	lives = clamp(lives, 0, 3)
	update_hearts()


func update_hearts():
	if heart1 == null or heart2 == null or heart3 == null:
		return

	heart1.visible = lives >= 1
	heart2.visible = lives >= 2
	heart3.visible = lives >= 3
