class_name tilemapproxy extends Object
#this whole file IS the class

var rows : int
var columns : int
var myMatrix : Array

#tiles in the proxy are filled with an array of bools.
#[bool,bool,bool,bool]
#[north,south,east,west]
#true == open
#false == closed

var DIRECTIONS = {"N"=0,"S"=1,"E"=2,"W"=3}
var OPPOSITES = {"N"="S","S"="N","E"="W","W"="E"}
var POLARIZED = {"N"=["E","W"],"S"=["E","W"],"E"=["N","S"],"W"=["N","S"]}

func _init(crows, molumns):
	rows = crows
	columns = molumns
	for i in range(rows):
		myMatrix.append([])
		for j in range(columns):
			myMatrix[i].append([false,false,false,false])

func printMe():
	for rog in myMatrix:
		print(rog)
