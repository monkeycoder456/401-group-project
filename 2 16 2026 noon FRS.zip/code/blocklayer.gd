class_name blocklayer extends Node
#for aid in maze generation
var rows : int
var columns : int
var myMatrix : Array
#-1 equals blank tile
# literally any other number means filled tile.

func _init(crows, molumns):
	rows = crows
	columns = molumns
	for i in range(rows):
		myMatrix.append([])
		for j in range(columns):
			myMatrix[i].append(-1)

func printMe():
	for rog in myMatrix:
		print(rog)

func getpoint(vector:Vector2i):
	return myMatrix[vector.y][vector.x]

func writepoint(vector: Vector2i, symbol):
	myMatrix[vector.y][vector.x] == symbol

func check_if_spot_free(vector : Vector2i):
	if(getpoint(vector) == -1):
		return true
	else:
		return false

func check_if_area_free(topleft : Vector2i, bottomright : Vector2i):
	#checks if the asked area is free, INCLUSIVE ON BOTH ENDS
	#if true, free
	#if false, not free
	for i in range(bottomright.y - topleft.y):
		#NOTE: ensure topleft is applied as offset
		print(i + topleft.y)
		for j in range(bottomright.x - topleft.x):
			#NOTE: ensure topleft is applied as offset
			print(j + topleft.x)
			if(check_if_spot_free(Vector2i(j + topleft.x,i + topleft.y)) == false):
				return false
			else:
				pass
	return true

func find_edges(origin:Vector2i):
	#this is baby's first flood fill algorithm
	#beginning from some origin:
	#check all neighboors
	#if the neighboor has -1, put it in edge array
	#if the neighboor doesn't have -1, put it in newly visited
	#put the current index/point we are in into visited array
	var edge : Array # stack
	var new : Array # stack
	var used : Array # stack

	# NORTH, SOUTH, EAST, WEST
	var neighboors = [Vector2i(0,-1),Vector2i(0,1),Vector2i(1,0),Vector2i(-1,0)]

	new.push_front(origin)
	while(new.is_empty() == false):
		var examiner = new.pop_front()
		#grab all the neighboors
		for direction in neighboors:
			var new_vect = examiner + direction
			if !used.has(new_vect):
				#it is not visited, do care
				#check if -1
				if myMatrix[new_vect.y][new_vect.x] == -1:
					#we found an edge
					edge.append(new_vect)
				else:
					#we found something in
					new.append(new_vect)
	return edge
	pass

func fill_area_with_num(num : int, topleft : Vector2,bottomright : Vector2i):
	for i in range(bottomright.y - topleft.y):
		#NOTE: ensure topleft is applied as offset
		print(i + topleft.y)
		for j in range(bottomright.x - topleft.x):
			#NOTE: ensure topleft is applied as offset
			print("Writing to...")
			print(Vector2i(j + topleft.x,i + topleft.y))
			myMatrix[i + topleft.y][j + topleft.x] = num
