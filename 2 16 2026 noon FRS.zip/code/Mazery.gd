class_name Mazery extends TileMapLayer

var DIRECTIONS = {"N"=0,"S"=1,"E"=2,"W"=3}
var OPPOSITES = {"N"="S","S"="N","E"="W","W"="E"}
var POLARIZED = {"N"=["E","W"],"S"=["E","W"],"E"=["N","S"],"W"=["N","S"]}

var ordinal = {"1":[0,-1],"2":[-1,-1],"3":[-1,0],"4":[0,0]}
var proxy : tilemapproxy
var blocks : blocklayer

#these are the shapes that are allowed to fill.
#if a shape doesn't work out then we must deviate...
#they are all rectangles and squares
#written as "name":[x,y]
#where x is the columns it occupies
#and y is the rows it occupies 
var SHAPES = {"Square2"=[2,2], "Rectangle32"=[3,2],"Rectangle23"=[2,3]}

# Called when the node enters the scene tree for the first time.
func _ready():
	#for i in ordinal.keys().size():
		#var dir = ordinal.get(ordinal.keys()[i])
		#set_cell(Vector2i(dir[0],dir[1]),1,Vector2i(3,3))
	_make_me_maze()
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	pass

func getRandomShape():
	#returns a random shape from shapes dict
	return SHAPES.get(SHAPES.keys().pick_random())

func shapeToVectorPair(topLeft : Vector2,shapeDimensions : Array):
	#returns two vectors
	var bottomRight = Vector2i(topLeft.x + shapeDimensions[0], topLeft.y + shapeDimensions[1])
	return [topLeft, bottomRight]

func checkIfBlockPlaceable(shape_to_place):
	pass

func _make_me_maze():
	#fill world with debug tile (le BLANK tile)
	var rows = 20
	var columns = 20
	proxy = tilemapproxy.new(rows,columns)
	blocks = blocklayer.new(rows,columns)
	var origin_tile = Vector2i(rows/2,columns/2)
	for i in range(rows): #rows
		for j in range(columns): #columns
			if (i == origin_tile.x) and (j == origin_tile.y):
				print("middle")
				set_cell(Vector2i(j,i),1,Vector2i(0,7))
			else:
				set_cell(Vector2i(j,i),1,Vector2i(4,1))
	#with the actual tile layer done, begin work on proxy
	#proxy.printMe()
	#blocks.printMe()
	#through blocks begin placing random blocks
	#you will need to loop the below until:
		#you can no longer place valid blocks
	#var shape_to_place = getRandomShape()
	#var shape_vectors = shapeToVectorPair(Vector2i(2,3),shape_to_place)
	#print(shape_vectors)
	#print(blocks.check_if_area_free(shape_vectors[0],shape_vectors[1]))
	#blocks.fill_area_with_num(0,shape_vectors[0],shape_vectors[1])
	#blocks.printMe()
	
	block_placing(origin_tile)
	
func find_valid_offset(edge : Vector2i,shapedefinition : Array):
	var offset = Vector2i(0,0)
	var worked = blocks.check_if_area_free(edge + shapedefinition[0] + offset, edge + shapedefinition[1] + offset)
	if(worked):
		pass
func block_placing(originVect : Vector2i):
	#origin vector is where the "holy square will go"
	blocks.writepoint(originVect,0)
	var can_place = true
	var block_num = 1
	while(can_place):
		#get a random shape
		var shape_to_place = getRandomShape()
		var shape_vectors = shapeToVectorPair(Vector2i(2,3),shape_to_place)
		print(shape_vectors)
		#shape vector is how we will represent our shape
		
		#find the edges of what we have worked with
		var edges = blocks.find_edges(originVect)
		
		#pick a random edge cell
		var tile_to_use = edges.pick_random()
		
		#check if we can put a block in that area
		#this part is somewhat arbitrary, so ensure you check every
			#way we can put a block there
#region debug cancel early
		can_place = false
#endregion
